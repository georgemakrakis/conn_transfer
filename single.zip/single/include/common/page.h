#ifndef __CR_COMMON_PAGE_H__
#define __CR_COMMON_PAGE_H__
#include "common/asm/page.h"
#endif
