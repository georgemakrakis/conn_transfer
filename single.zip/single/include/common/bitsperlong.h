#ifndef __CR_COMMON_BITSPERLONG_H__
#define __CR_COMMON_BITSPERLONG_H__
#include "common/asm/bitsperlong.h"
#endif
